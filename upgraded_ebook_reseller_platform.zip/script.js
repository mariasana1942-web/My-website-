
function captureRef(){
const params=new URLSearchParams(window.location.search)
const ref=params.get("ref")
if(ref){localStorage.setItem("referrer",ref)}
}

function goCheckout(){
const ref=localStorage.getItem("referrer")||"none"
window.location.href="checkout.html?ref="+ref
}

function simulatePayment(){

const params=new URLSearchParams(window.location.search)
const ref=params.get("ref")||"none"

let orders=JSON.parse(localStorage.getItem("orders")||"[]")

orders.push({
referrer:ref,
amount:10,
commission:5
})

localStorage.setItem("orders",JSON.stringify(orders))

window.location.href="download.html"
}

function login(){

const user=document.getElementById("username").value
localStorage.setItem("reseller",user)

window.location.href="dashboard.html"
}

function loadDashboard(){

const user=localStorage.getItem("reseller")
const orders=JSON.parse(localStorage.getItem("orders")||"[]")

let sales=0
let commission=0

orders.forEach(o=>{
if(o.referrer===user){
sales++
commission+=o.commission
}
})

document.getElementById("user").innerText=user
document.getElementById("sales").innerText=sales
document.getElementById("commission").innerText="$"+commission
document.getElementById("refLink").innerText=window.location.origin+"/index.html?ref="+user
}

function loadAdmin(){

const orders=JSON.parse(localStorage.getItem("orders")||"[]")

let total=orders.length
let revenue=0
let commissions=0

orders.forEach(o=>{
revenue+=o.amount
commissions+=o.commission
})

document.getElementById("totalSales").innerText=total
document.getElementById("revenue").innerText="$"+revenue
document.getElementById("commissions").innerText="$"+commissions
}
